import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='alwaseem',
    application_name='todo-list-serverless',
    app_uid='hKMvCGBVxQVY94H8Vv',
    org_uid='991f0dd9-8648-4fe9-8213-c30fdb1d333a',
    deployment_uid='0dfced5f-8dff-4865-b29a-156b9894f067',
    service_name='api-rest',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='5.1.0',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'api-rest-dev-update', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('todos/update.update')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
